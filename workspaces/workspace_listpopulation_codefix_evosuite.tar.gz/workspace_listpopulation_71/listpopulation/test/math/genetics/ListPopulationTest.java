package math.genetics;

import static org.junit.Assert.*;

import java.util.Collection;
import java.util.LinkedList;
import java.util.List;

import org.junit.Test;

public class ListPopulationTest {

	@Test
	public void test() throws Throwable {
		ElitisticListPopulation elitisticListPopulation0 = new ElitisticListPopulation(1389, 0.0);
		LinkedList<Chromosome> linkedList0 = new LinkedList<Chromosome>();
		LinkedList<Integer> linkedList1 = new LinkedList<Integer>();
		DummyBinaryChromosome dummyBinaryChromosome0 = new DummyBinaryChromosome((List<Integer>) linkedList1);
		AbstractListChromosome<Integer> abstractListChromosome0 = dummyBinaryChromosome0.newFixedLengthChromosome(linkedList1);
		linkedList0.add((Chromosome) abstractListChromosome0);
		linkedList0.addLast(dummyBinaryChromosome0);
		elitisticListPopulation0.addChromosomes(linkedList0);
		DummyBinaryChromosome dummyBinaryChromosome1 = (DummyBinaryChromosome)elitisticListPopulation0.getFittestChromosome();
		assertNotSame(dummyBinaryChromosome1, dummyBinaryChromosome0);
		assertEquals(1389, elitisticListPopulation0.getPopulationLimit());
	}

}