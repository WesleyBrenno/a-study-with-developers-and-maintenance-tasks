package collections.comparators;

import static org.junit.Assert.*;

import java.util.LinkedList;
import java.util.List;

import org.junit.Test;

/**
 *
 */
public class FixedOrderComparatorTest {

	@Test
	public void test()  throws Throwable  {
		LinkedList<Object> linkedList0 = new LinkedList<Object>();
		FixedOrderComparator fixedOrderComparator0 = new FixedOrderComparator((List) linkedList0);
		Object object0 = new Object();
		fixedOrderComparator0.setUnknownObjectBehavior(0);
		int int0 = fixedOrderComparator0.compare((Object) null, object0);
		assertTrue(fixedOrderComparator0.isLocked());
		assertEquals(0, int0);
	}

}
