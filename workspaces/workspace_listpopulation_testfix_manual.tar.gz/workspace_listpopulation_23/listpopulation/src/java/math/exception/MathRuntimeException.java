package math.exception;

import math.exception.util.ExceptionContext;
import math.exception.util.ExceptionContextProvider;
import math.exception.util.Localizable;

/**
 * All exceptions (except {@link NullArgumentException}) inherit from this class.
 * In most cases, this class should not be instantiated directly: it should
 * serve as a base class for implementing exception classes that describe a
 * specific "problem".
 *
 */
public class MathRuntimeException extends RuntimeException
    implements ExceptionContextProvider {
    /** Serializable version Id. */
    private static final long serialVersionUID = 20120926L;
    /** Context. */
    private final ExceptionContext context;

    /**
     * @param pattern Message pattern explaining the cause of the error.
     * @param args Arguments.
     */
    public MathRuntimeException(Localizable pattern,
                                Object ... args) {
        context = new ExceptionContext(this);
        context.addMessage(pattern, args);
    }

    /** {@inheritDoc} */
    public ExceptionContext getContext() {
        return context;
    }

    /** {@inheritDoc} */
    @Override
    public String getMessage() {
        return context.getMessage();
    }

    /** {@inheritDoc} */
    @Override
    public String getLocalizedMessage() {
        return context.getLocalizedMessage();
    }
}
