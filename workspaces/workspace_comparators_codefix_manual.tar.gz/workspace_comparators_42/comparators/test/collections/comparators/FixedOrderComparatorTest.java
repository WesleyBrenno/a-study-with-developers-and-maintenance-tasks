package collections.comparators;

import static org.junit.Assert.*;

import java.util.Arrays;
import java.util.LinkedList;

import org.junit.Test;

/**
 *
 */
public class FixedOrderComparatorTest {

	/**
	 * Top cities of the world, by population including metro areas.
	 */
	public static final String topCities[] = new String[] {
		"Tokyo",
		"Mexico City",
		"Mumbai",
		"Sao Paulo",
		"New York",
		"Shanghai",
		"Lagos",
		"Los Angeles",
		"Calcutta",
		"Buenos Aires"
	};

	@Test
	public void test() {
		FixedOrderComparator comparator = new FixedOrderComparator(topCities);
		try {
			comparator.compare("New York", "Minneapolis");
			fail("Should have thrown a IllegalArgumentException");
		} catch (IllegalArgumentException e) {
			// success-- ignore
		}
		try {
			comparator.compare("Minneapolis", "New York");
			fail("Should have thrown a IllegalArgumentException");
		} catch (IllegalArgumentException e) {
			// success-- ignore
		}
		assertEquals(FixedOrderComparator.UNKNOWN_THROW_EXCEPTION, comparator.getUnknownObjectBehavior());

		comparator = new FixedOrderComparator(topCities);
		comparator.setUnknownObjectBehavior(FixedOrderComparator.UNKNOWN_BEFORE);
		assertEquals(FixedOrderComparator.UNKNOWN_BEFORE, comparator.getUnknownObjectBehavior());
		LinkedList keys = new LinkedList(Arrays.asList(topCities));
		keys.addFirst("Minneapolis");

		assertEquals(-1, comparator.compare("Minneapolis", "New York"));
		assertEquals( 1, comparator.compare("New York", "Minneapolis"));
		assertEquals( 0, comparator.compare("Minneapolis", "St Paul"));
	}

}
