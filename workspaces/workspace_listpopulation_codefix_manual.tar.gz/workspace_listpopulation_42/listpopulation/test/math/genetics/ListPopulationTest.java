package math.genetics;

import java.util.ArrayList;

import org.junit.Assert;
import org.junit.Test;

public class ListPopulationTest {

	@Test
	public void test() {
		Chromosome c1 = new Chromosome() {
			public double fitness() {
				return 0;
			}
		};
		Chromosome c2 = new Chromosome() {
			public double fitness() {
				return 10;
			}
		};
		Chromosome c3 = new Chromosome() {
			public double fitness() {
				return 15;
			}
		};

		ArrayList<Chromosome> chromosomes = new ArrayList<Chromosome> ();
		chromosomes.add(c1);
		chromosomes.add(c2);
		chromosomes.add(c3);

		ListPopulation population = new ListPopulation(chromosomes, 10) {
			public Population nextGeneration() {
				// not important
				return null;
			}
		};

		Assert.assertEquals(c3, population.getFittestChromosome());
	}

}